<?php
/**
 * Temporary debug endpoint — shows what scope is being applied.
 * Visit: /api/users/debug-scope
 * DELETE this file after debugging.
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../api/response.php';
require_once __DIR__ . '/../../middleware/lgu_auth.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

requireLguAuth();

$user    = $GLOBALS['lgu_user'];
$myBrgyId = (int)($user['barangay_id'] ?? 0);

$pdo = Database::getInstance();
$s = $pdo->prepare('SELECT id, name, latitude, longitude FROM barangays WHERE id = ? LIMIT 1');
$s->execute([$myBrgyId]);
$center = $s->fetch();

// Count total users vs scoped users
$total = $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();

echo json_encode([
    'lgu_user'     => $user,
    'barangay'     => $center,
    'total_users'  => (int)$total,
    'radius_km'    => 3.0,
    'note'         => 'If barangay latitude/longitude are null, scoping falls back to barangay_id only',
], JSON_PRETTY_PRINT);
